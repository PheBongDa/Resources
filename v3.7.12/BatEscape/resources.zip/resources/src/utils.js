function customManifestStr(hots) {
    return JSON.stringify({
        "packageUrl": hots + '/',
        "remoteManifestUrl": hots + '/project.manifest',
        "remoteVersionUrl": hots + '/version.manifest',
        "version": "0.0.0",
        "assets": {
        },
        "searchPaths": []
    });
}

function versionCompareHandle(verA, verB) {
    console.log(verA + " -> " + verB);
    var vA = verA.split('.');
    var vB = verB.split('.');
    for (var i = 0; i < vA.length; ++i) {
        var a = parseInt(vA[i]);
        var b = parseInt(vB[i] || 0);
        if (a === b) {
            continue;
        }
        else {
            return a - b;
        }
    }
    if (vB.length > vA.length) {
        return -1;
    }
    else {
        return 0;
    }
};

var Request = {

    STATE: {
        SUCCESS: 1,
        FAIL: 2,
        ERROR: 3
    },

    get: function (url, callBack) {
        var self = this;
        var xhr = cc.loader.getXMLHttpRequest();
        xhr.onreadystatechange = function () {
            if ((xhr.readyState == 4) && (xhr.status == 200)) {
                cc.log('ResponseText = ' + xhr.responseText);
                callBack(self.STATE.SUCCESS, xhr.responseText);
            } else {
                callBack(self.STATE.FAIL, xhr.responseText);
            }
        };

        xhr.ontimeout = function () {
            callBack(self.STATE.ERROR);
        };

        xhr.onerror = function () {
            callBack(self.STATE.ERROR);
        };

        xhr.timeout = 20000;
        cc.log('GET URL ' + url);
        xhr.open('GET', url);
        xhr.setRequestHeader('Content-Type', 'application/json; charset=UTF-8');
        xhr.send();
    },

    post: function (url, callBack) {
        var self = this;
        var xhr = cc.loader.getXMLHttpRequest();
        xhr.onreadystatechange = function () {
            if ((xhr.readyState == 4) && (xhr.status == 200)) {
                cc.log('ResponseText = ' + xhr.responseText);
                callBack(self.STATE.SUCCESS, xhr.responseText);
            } else {
                callBack(self.STATE.FAIL, xhr.responseText);
            }
        };

        xhr.ontimeout = function () {
            callBack(self.STATE.ERROR);
        };

        xhr.onerror = function () {
            callBack(self.STATE.ERROR);
        };

        xhr.timeout = 20000;
        cc.log('POST URL ' + url);
        xhr.open('POST', url);
        xhr.setRequestHeader('Content-Type', 'application/json; charset=UTF-8');
        xhr.send();
    }
};
