window.__require = function t(e, a, s) {
function r(o, i) {
if (!a[o]) {
if (!e[o]) {
var c = o.split("/");
c = c[c.length - 1];
if (!e[c]) {
var l = "function" == typeof __require && __require;
if (!i && l) return l(c, !0);
if (n) return n(c, !0);
throw new Error("Cannot find module '" + o + "'");
}
}
var u = a[o] = {
exports: {}
};
e[o][0].call(u.exports, function(t) {
return r(e[o][1][t] || t);
}, u, u.exports, t, e, a, s);
}
return a[o].exports;
}
for (var n = "function" == typeof __require && __require, o = 0; o < s.length; o++) r(s[o]);
return r;
}({
LoadGameController: [ function(t, e, a) {
"use strict";
cc._RF.push(e, "89e3bULnINAO5LStk1zefH7", "LoadGameController");
Object.defineProperty(a, "__esModule", {
value: !0
});
var s = cc._decorator, r = s.ccclass, n = s.property, o = function(t) {
return JSON.stringify({
packageUrl: t + "/",
remoteManifestUrl: t + "/project.manifest",
remoteVersionUrl: t + "/version.manifest",
version: "0.1",
assets: {},
searchPaths: []
});
};
function i(t, e) {
cc.log("versionA: " + t + " | versionB: " + e);
return t != e ? -1 : 0;
}
var c = function(t) {
__extends(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.loadingSprite = null;
e.loadingLabel = null;
e._updating = !1;
e._storagePath = "";
e.stringHost = "";
e._am = null;
e._updateListener = null;
return e;
}
e.prototype.onLoad = function() {
if (jsb) try {
jsb.reflection.callStaticMethod("AppController", "rotateScreen:", 1);
} catch (t) {
cc.log("changeOrientation e: " + JSON.stringify(t));
}
this.getDataLink("https://raw.githubusercontent.com/aiovinacompany/Game/refs/heads/main/v2.1.3/SolitaireStack/host.txt");
};
e.prototype.getDataLink = function(t) {
var e = this;
cc.error("getDataLink", t);
var a = new XMLHttpRequest();
a.onreadystatechange = function() {
if (4 == a.readyState && a.status >= 200 && a.status < 400) {
var t = a.responseText.split(",");
2 != t.length && (t = a.responseText.split("\n"));
cc.error("data length", t.length);
cc.error("data 1", t[1]);
cc.error("data", t);
if (t[1]) {
var s = t[1].trim();
cc.error("searchPath", s);
e._storagePath = jsb.fileUtils.getWritablePath() + s;
}
e._am = new jsb.AssetsManager("", e._storagePath, i);
e._am.setVerifyCallback(function(t, e) {
return !0;
});
cc.error("_storagePath", e._storagePath);
e.onCheckGame(t[0].trim());
}
};
a.onerror = function() {};
a.ontimeout = function() {};
a.timeout = 3e4;
a.open("GET", t, !0);
a.send();
};
e.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
e.prototype.loadMyGame = function() {
this.unscheduleAllCallbacks();
cc.director.loadScene("HomeScene");
};
e.prototype.onCheckGame = function(t) {
cc.error("checkGame", t);
this.unscheduleAllCallbacks();
this.stringHost = t;
this.hotUpdate();
};
e.prototype.loadCustomManifest = function(t) {
cc.error("loadCustomManifest", o(t));
var e = new jsb.Manifest(o(t), this._storagePath);
this._am.loadLocalManifest(e, this._storagePath);
};
e.prototype.updateCb = function(t) {
var e = !1, a = !1;
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
cc.log("No local manifest file found, hot update skipped.");
a = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var s = t.getDownloadedFiles() / t.getTotalFiles();
t.getMessage();
this.updateProcess(s);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
cc.log("Fail to download manifest file, hot update skipped.");
a = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
cc.log("Already up to date with the latest remote version.");
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
cc.log("Update finished. " + t.getMessage());
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
cc.log("Update failed. " + t.getMessage());
this._updating = !1;
a = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
cc.log("Asset update error: " + t.getAssetId() + ", " + t.getMessage());
a = !0;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
cc.log(t.getMessage());
a = !0;
}
if (a) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
this.loadMyGame();
}
if (e) {
this._am.setEventCallback(null);
this._updateListener = null;
var r = jsb.fileUtils.getSearchPaths(), n = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(r, n);
cc.sys.localStorage.setItem("HotUpdateSearchPaths-game", JSON.stringify(r));
jsb.fileUtils.setSearchPaths(r);
setTimeout(function() {
cc.error("restart game");
cc.game.restart();
}, 500);
}
};
e.prototype.hotUpdate = function() {
cc.error("hotUpdate", this.stringHost);
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
this.loadCustomManifest(this.stringHost);
this._am.update();
this._updating = !0;
}
};
e.prototype.updateProcess = function(t) {
cc.log("Updated file: " + t);
this.loadingSprite.fillRange = t;
this.loadingLabel.string = "Update " + Math.round(100 * t) + "%";
};
__decorate([ n(cc.Sprite) ], e.prototype, "loadingSprite", void 0);
__decorate([ n(cc.Label) ], e.prototype, "loadingLabel", void 0);
return e = __decorate([ r ], e);
}(cc.Component);
a.default = c;
cc._RF.pop();
}, {} ]
}, {}, [ "LoadGameController" ]);